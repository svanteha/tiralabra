package tiralabra.kaytto;


import tiralabra.kaytto.Kayttoliittyma;


/**
 *
 * @author Svante Häggblom
 */
public class Tiralabra {

    /**
     * Käynnistää ohjelman
     */
    public static void main(String[] args) {
        Kayttoliittyma kayttoliittyma = new Kayttoliittyma();
        kayttoliittyma.start();
    }
}
